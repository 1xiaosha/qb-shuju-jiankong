#!/bin/bash

# 定义 qBittorrent 实例列表（名称=地址）
declare -A QBS
QBS["qb-movie"]="http://ip:端口"
QBS["qb-vt"]="http://ip:端口"

# 登录凭据
USERNAME="用户名"
PASSWORD="密码"

# 数据库路径
DB="/volume1/docker/qb-shuju-jiankong/data.db" #改为自己的地址
TODAY=$(date +%Y-%m-%d)

# 初始化数据库（如未创建）
if [ ! -f "$DB" ]; then
  echo "数据库不存在，创建中..."
  sqlite3 "$DB" "CREATE TABLE traffic (
    date TEXT,
    client TEXT,
    upload REAL,
    download REAL
  );"
fi

# 遍历每个 qB 实例收集数据
for name in "${!QBS[@]}"; do
  URL="${QBS[$name]}"
  echo "正在处理 $name ($URL)"

  # 登录获取 SID
  COOKIE=$(curl -c - -s -X POST -d "username=$USERNAME&password=$PASSWORD" "$URL/api/v2/auth/login" | grep SID | awk '{print $7}')
  
  if [ -z "$COOKIE" ]; then
    echo "⚠️ 登录失败：$name"
    continue
  fi

  # 获取传输信息
  JSON=$(curl -s --cookie "SID=$COOKIE" "$URL/api/v2/transfer/info")
  UP=$(echo "$JSON" | jq .up_info_data)
  DOWN=$(echo "$JSON" | jq .dl_info_data)

  # 处理 null 情况
  UP=${UP:-0}
  DOWN=${DOWN:-0}

  # 字节转 GB（保留2位小数）
  UP_GB=$(awk "BEGIN {printf \"%.2f\", $UP/1024/1024/1024}")
  DOWN_GB=$(awk "BEGIN {printf \"%.2f\", $DOWN/1024/1024/1024}")

  echo "✅ $name 上传: $UP_GB GB，下载: $DOWN_GB GB"

  # 写入数据库
  sqlite3 "$DB" "INSERT INTO traffic (date, client, upload, download) VALUES ('$TODAY', '$name', $UP_GB, $DOWN_GB);"
done
