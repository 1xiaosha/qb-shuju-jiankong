#!/bin/bash

# === 配置 ===
source /volume1/docker/qb-shuju-jiankong/.env

declare -A QBS
QBS["qb-movie"]="http://192.168.50.201:8999"
QBS["qb-vt"]="http://192.168.50.201:8989"
QBS["qb-heigong1"]="http://192.168.50.201:8086"
QBS["qb-heigong2"]="http://192.168.50.201:8789"

USERNAME="admin"
PASSWORD="xiaosha@1120"

DB="/volume1/docker/qb-shuju-jiankong/data.db"
TODAY=$(date +%Y-%m-%d)
YESTERDAY=$(date -d "yesterday" +%Y-%m-%d)
LOGFILE="/volume1/docker/qb-shuju-jiankong/fetch_traffic.log"

echo -e "\n🕒 $(date '+%Y-%m-%d %H:%M:%S') 开始采集数据" | tee -a "$LOGFILE"

# === 初始化数据库（自动添加字段） ===
if [ ! -f "$DB" ]; then
  sqlite3 "$DB" "
    CREATE TABLE traffic (
      date TEXT,
      client TEXT,
      upload REAL,
      download REAL,
      upload_bytes INTEGER,
      download_bytes INTEGER
    );
  "
else
  # 添加缺失字段（兼容旧版本）
  for col in upload_bytes download_bytes; do
    if ! sqlite3 "$DB" "PRAGMA table_info(traffic);" | grep -q "$col"; then
      sqlite3 "$DB" "ALTER TABLE traffic ADD COLUMN $col INTEGER;"
    fi
  done
fi

# 删除当天已有数据，避免重复写入
sqlite3 "$DB" "DELETE FROM traffic WHERE date = '$TODAY';"

# === 开始采集 ===
total_up=0
total_down=0

for name in "${!QBS[@]}"; do
  URL=${QBS[$name]}
  echo "🔄 正在处理 $name ($URL)" | tee -a "$LOGFILE"

  # 登录获取 Cookie（SID）
  COOKIE=$(curl -c - -s -X POST -d "username=$USERNAME&password=$PASSWORD" "$URL/api/v2/auth/login" | grep SID | awk '{print $7}')
  if [ -z "$COOKIE" ]; then
    echo "❌ 登录失败: $name" | tee -a "$LOGFILE"
    continue
  fi

  # 获取流量信息 JSON
  JSON=$(curl -s --cookie "SID=$COOKIE" "$URL/api/v2/transfer/info")

  UP_BYTES=$(echo "$JSON" | jq .up_info_data)
  DOWN_BYTES=$(echo "$JSON" | jq .dl_info_data)

  UP_BYTES=${UP_BYTES:-0}
  DOWN_BYTES=${DOWN_BYTES:-0}

  # 查询昨天最后一次累计上传/下载字节数
  read LAST_UP LAST_DOWN <<< $(sqlite3 "$DB" "SELECT upload_bytes, download_bytes FROM traffic WHERE client = '$name' AND date = '$YESTERDAY' ORDER BY rowid DESC LIMIT 1;")
  LAST_UP=${LAST_UP:-0}
  LAST_DOWN=${LAST_DOWN:-0}

  # 计算上传/下载增量字节数
  DELTA_UP_BYTES=$((UP_BYTES - LAST_UP))
  DELTA_DOWN_BYTES=$((DOWN_BYTES - LAST_DOWN))

  # 防止负数（如客户端重启或数据归零）
  if [ "$DELTA_UP_BYTES" -lt 0 ]; then DELTA_UP_BYTES=0; fi
  if [ "$DELTA_DOWN_BYTES" -lt 0 ]; then DELTA_DOWN_BYTES=0; fi

  # 字节转 GB（保留两位小数）
  UP_GB=$(awk "BEGIN {printf \"%.2f\", $DELTA_UP_BYTES / 1024 / 1024 / 1024}")
  DOWN_GB=$(awk "BEGIN {printf \"%.2f\", $DELTA_DOWN_BYTES / 1024 / 1024 / 1024}")

  echo "✅ $name 上传: $UP_GB GB，下载: $DOWN_GB GB" | tee -a "$LOGFILE"

  # 写入数据库
  sqlite3 "$DB" "INSERT INTO traffic (date, client, upload, download, upload_bytes, download_bytes)
    VALUES ('$TODAY', '$name', $UP_GB, $DOWN_GB, $UP_BYTES, $DOWN_BYTES);"

  # 统计汇总
  total_up=$(awk "BEGIN {print $total_up + $UP_GB}")
  total_down=$(awk "BEGIN {print $total_down + $DOWN_GB}")
done

echo "📦 今日汇总上传: $total_up GB，下载: $total_down GB" | tee -a "$LOGFILE"
