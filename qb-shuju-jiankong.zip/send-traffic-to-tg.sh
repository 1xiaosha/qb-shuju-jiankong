#!/bin/bash

# 设置代理（所有 curl 请求走代理）
export http_proxy="http://192.168.50.201:20171"
export https_proxy="http://192.168.50.201:20171"

# 载入环境变量
source /volume1/docker/qb-shuju-jiankong/.env

JSON_FILE="/volume1/docker/qb-shuju-jiankong/public/traffic.json"
TODAY=$(date +%Y-%m-%d)

# 检查文件是否存在
if [ ! -f "$JSON_FILE" ]; then
  echo "❌ 找不到 traffic.json 文件: $JSON_FILE"
  exit 1
fi

MSG="📊 *qBittorrent 每日流量报告*（$TODAY）"

# 读取所有客户端名到数组
mapfile -t clients < <(jq -r 'keys[]' "$JSON_FILE")

# 遍历客户端，拼接消息
for client in "${clients[@]}"; do
  upload=$(jq -r --arg c "$client" --arg d "$TODAY" '.[$c][$d].upload // empty' "$JSON_FILE")
  download=$(jq -r --arg c "$client" --arg d "$TODAY" '.[$c][$d].download // empty' "$JSON_FILE")

  # 只有当上传和下载数据都存在且不为空时才添加
  if [ -n "$upload" ] && [ -n "$download" ]; then
    MSG+="
➡️ $client
⬆️ ${upload} GB
⬇️ ${download} GB"
  fi
done

# 调试打印（可选，测试时打开，发送后关闭）
 echo -e "$MSG"

# 发送消息到 Telegram
curl -s --proxy "$http_proxy" -X POST "https://api.telegram.org/bot${TG_BOT_TOKEN}/sendMessage" \
  -d chat_id="${TG_CHAT_ID}" \
  -d parse_mode="Markdown" \
  -d text="$MSG"
