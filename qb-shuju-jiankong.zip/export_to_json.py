import sqlite3, json
from collections import defaultdict

DB = '/volume1/docker/qb-shuju-jiankong/data.db' #改为自己的文件地址
OUTPUT = '/volume1/docker/qb-shuju-jiankong/public/traffic.json' #改为自己的文件地址

conn = sqlite3.connect(DB)
cursor = conn.cursor()

cursor.execute("""
SELECT date, client, upload, download FROM traffic
WHERE date >= date('now', '-30 day')
ORDER BY date ASC;
""")

rows = cursor.fetchall()
result = defaultdict(lambda: defaultdict(dict))

for date, client, up, down in rows:
    result[client][date] = {'upload': up, 'download': down}

with open(OUTPUT, 'w') as f:
    json.dump(result, f, indent=2)

conn.close()
