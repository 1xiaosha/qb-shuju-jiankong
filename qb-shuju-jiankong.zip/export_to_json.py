import sqlite3, json
from collections import defaultdict
import datetime
import os

DB = '/volume1/docker/qb-shuju-jiankong/data.db'
OUTPUT = '/volume1/docker/qb-shuju-jiankong/public/traffic.json'
CACHE_BUSTER_FILE = '/volume1/docker/qb-shuju-jiankong/public/traffic.json.url'

conn = sqlite3.connect(DB)
cursor = conn.cursor()

cursor.execute("""
SELECT date, client, upload, download FROM traffic
WHERE date >= date('now', '-30 day')
ORDER BY date ASC;
""")

rows = cursor.fetchall()
result = defaultdict(lambda: defaultdict(dict))

for date, client, up, down in rows:
    result[client][date] = {'upload': up, 'download': down}

# 写入主 JSON 数据文件
with open(OUTPUT, 'w') as f:
    json.dump(result, f, indent=2)

# 生成带时间戳的防缓存 URL 用于前端加载
timestamp = int(datetime.datetime.now().timestamp())
with open(CACHE_BUSTER_FILE, 'w') as f:
    f.write(f"/traffic.json?t={timestamp}")

# 可选输出日志
print(f"✅ 导出完成，共 {len(rows)} 条记录，时间戳: {timestamp}")

conn.close()
